<?php

namespace IngresseUserImport\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class ImportCommand extends Command
{
    protected function configure()
    {
        $this
            ->setName('import:user')
            ->setDescription('Import User to Elastic Search')
            // ->addArgument(
            //     'name',
            //     InputArgument::OPTIONAL,
            //     'Who do you want to greet?'
            // )
            // ->addOption(
            //    'yell',
            //    null,
            //    InputOption::VALUE_NONE,
            //    'If set, the task will yell in uppercase letters'
            // )
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        // $name = $input->getArgument('name');
        // if ($name) {
        //     $text = 'Hello '.$name;
        // } else {
        //     $text = 'Hello';
        // }

        // if ($input->getOption('yell')) {
        //     $text = strtoupper($text);
        // }

        $conn = new \PDO(
            'mysql:host=127.0.0.1;dbname=ingresse',
            'ingresse',
            'ingresse'
        );

        $stmt = $conn->prepare("SELECT * FROM user limit 1");

        $stmt->execute();

        while($row = $stmt->fetch()) {
            $data = new \DateTime($row['creationdate']);

            $data = [
                'user_id'  => $row['id'],
                'email'    => $row['email'],
                'name'     => $row['name'],
                'created'  => $data->format('d/m/Y H:i'),
                'friends'       => [
                    // [
                    //     'name'     => 'Jefferson',
                    //     'lastname' => 'Silva',
                    //     'email'    => 'jefferson.silva@ingresse.com'
                    // ],
                ],
            ];
            $this->sendRequest($output, json_encode($data, true));
        }
    }

    protected function sendRequest($output, $data)
    {
        $client = new \GuzzleHttp\Client();

        try {
            $response = $client->put('127.0.0.1:9200', [
                'headers' => [],
                'body'    => $data
            ]);

            $output->writeln($response->getCode());
        } catch (\Exception $e) {
            $output->writeln($e->getMessage());
        }

    }
}
